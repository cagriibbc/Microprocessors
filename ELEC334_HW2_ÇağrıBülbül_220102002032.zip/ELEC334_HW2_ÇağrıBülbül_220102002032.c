#include "stm32f1xx.h"
#include <stdint.h>

/* ==========================================
 * DONANIM & AYAR TANIMLAMALARI
 * ========================================== */

/* --- Batarya Ayarları --- */
#define BATTERY_LOW_MV      3400     // 3.4V altı tehlikeli
#define ADC_REF_MV          3300     // 3.3V Referans
#define ADC_DIV_FACTOR      2        // Gerilim bölücü oranı (R1=R2 ise 2)
/* --- PWM ve Hız Ayarları (8 MHz Clock için) --- */
#define PWM_ARR_VAL         999      // Periyot (0..999 -> 1000 adım)
#define PWM_PRESCALER       7        // 8MHz / (7+1) / 1000 = 1 kHz PWM Frekansı
#define SPEED_FAST          800      // %80 Hız
#define SPEED_TURN          600      // %60 Dönüş Hızı
#define SPEED_STOP          0        // Dur
#define PIN_SENSOR_L        0   // PB0 (Sol Sensör)
#define PIN_SENSOR_R        1   // PB1 (Sağ Sensör)
#define PIN_BUZZER          5   // PB5 (Buzzer)
#define PIN_BUTTON          10  // PB10 (Başlat Butonu)

/* --- Robot Durumları --- */
typedef enum {
    STATE_IDLE = 0, // Bekleme
    STATE_RUN  = 1  // Çalışma (Çizgi İzleme)
} RobotState_t;

volatile RobotState_t currentStat = STATE_IDLE;

/* ==========================================
 * FONKSİYON PROTOTİPLERİ
 * ========================================== */
void System_Init(void);
void GPIO_Init(void);
void ADC_Init(void);
void TIM2_PWM_Init(void);

uint16_t ADC_Read(void);
void Check_Battery_Voltage(void);
void Button_Check(void);
void Line_Follower_Loop(void);
void Set_Motor_Speed(uint16_t left_pwm, uint16_t right_pwm);
void Simple_Delay_ms(uint32_t ms);

/* ==========================================
 * MAIN FONKSİYONU
 * ========================================== */
int main(void)
{
    /* Tüm donanımı başlat */
    System_Init();

    /* Başlangıç uyarısı (Buzzer bip) */
    GPIOB->ODR |= (1 << PIN_BUZZER);
    Simple_Delay_ms(100);
    GPIOB->ODR &= ~(1 << PIN_BUZZER);

    while (1)
    {
        /* 1. Güvenlik: Pil kontrolü */
        Check_Battery_Voltage();

        /* 2. Kullanıcı Girişi: Buton kontrolü */
        Button_Check();

        /* 3. Ana Mantık: Robot durumu */
        if (currentStat == STATE_RUN) {
            Line_Follower_Loop();
        } else {
            Set_Motor_Speed(SPEED_STOP, SPEED_STOP);
        }

        /* Döngü rahatlatma */
        Simple_Delay_ms(1);
    }
}

/* ==========================================
 * BAŞLATMA (INIT) FONKSİYONLARI
 * ========================================== */
void System_Init(void) {
    GPIO_Init();
    ADC_Init();
    TIM2_PWM_Init();
}

void GPIO_Init(void) {
    /* Clock'ları Aktif Et: GPIOA, GPIOB, ADC1, TIM2, AFIO */
    RCC->APB2ENR |= (1 << 0) | (1 << 2) | (1 << 3) | (1 << 9);
    RCC->APB1ENR |= (1 << 0); // TIM2 Clock

    /* --- GPIOA Ayarları (Motor Sürücü & ADC) --- */

    // PA0: Analog Input (ADC) -> 0x0
    GPIOA->CRL &= ~(0xF << 0);

    // PA1 (TIM2_CH2 PWM): Alt. Func. Push-Pull -> 0xB
    GPIOA->CRL &= ~(0xF << 4);
    GPIOA->CRL |=  (0xB << 4);

    // PA2 (DIR Left): Output Push-Pull -> 0x3
    GPIOA->CRL &= ~(0xF << 8);
    GPIOA->CRL |=  (0x3 << 8);

    // PA3 (TIM2_CH4 PWM): Alt. Func. Push-Pull -> 0xB
    GPIOA->CRL &= ~(0xF << 12);
    GPIOA->CRL |=  (0xB << 12);

    // PA4 (DIR Right): Output Push-Pull -> 0x3
    GPIOA->CRL &= ~(0xF << 16);
    GPIOA->CRL |=  (0x3 << 16);

    // Motor yön pinlerini varsayılan olarak LOW (İleri) yap
    GPIOA->BRR = (1 << 2) | (1 << 4);

    /* --- GPIOB Ayarları (Sensörler, Buton, Buzzer) --- */

    // PB0, PB1: Input Floating (Sensörler) -> 0x4
    GPIOB->CRL &= ~(0xF << 0); GPIOB->CRL |= (0x4 << 0);
    GPIOB->CRL &= ~(0xF << 4); GPIOB->CRL |= (0x4 << 4);

    // PB5: Output Push-Pull (Buzzer) -> 0x3
    GPIOB->CRL &= ~(0xF << 20);
    GPIOB->CRL |=  (0x3 << 20);

    // PB10: Input Pull-Up (Buton) -> CRH ayarı
    GPIOB->CRH &= ~(0xF << 8); // PB10 temizle
    GPIOB->CRH |=  (0x8 << 8); // Input with Pull-up/down
    GPIOB->ODR |=  (1 << PIN_BUTTON); // ODR=1 yaparak Pull-UP seçildi
}

void TIM2_PWM_Init(void) {
    /* 8MHz HSI Clock varsayımıyla 1kHz PWM */
    TIM2->PSC = PWM_PRESCALER;
    TIM2->ARR = PWM_ARR_VAL;

    /* CH2 (PA1) PWM Mode 1 */
    TIM2->CCMR1 &= ~(0xFF << 8);
    TIM2->CCMR1 |= (0x6 << 12) | (1 << 11); // Mode 1, Preload Enable

    /* CH4 (PA3) PWM Mode 1 */
    TIM2->CCMR2 &= ~(0xFF << 8);
    TIM2->CCMR2 |= (0x6 << 12) | (1 << 11); // Mode 1, Preload Enable

    /* Çıkışları Aktif Et */
    TIM2->CCER |= (1 << 4);  // CC2E
    TIM2->CCER |= (1 << 12); // CC4E

    /* Timer'ı Başlat */
    TIM2->CR1 |= (1 << 0);   // CEN
}

void ADC_Init(void) {
    /* ADC Prescaler: PCLK2 / 6 (72MHz değil 8MHz de olsa güvenli bölücü) */
    RCC->CFGR |= (2 << 14);

    /* ADC'yi Aç */
    ADC1->CR2 |= (1 << 0); // ADON

    /* Stabilizasyon için bekle */
    Simple_Delay_ms(1);

    /* Kalibrasyon */
    ADC1->CR2 |= (1 << 2); // CAL start
    while (ADC1->CR2 & (1 << 2)); // Bit sıfırlanana kadar bekle

    /* Örnekleme süresi ayarı (Channel 0 -> PA0) */
    ADC1->SMPR2 |= (7 << 0); // Max örnekleme süresi (stabilite için)
}

/* ==========================================
 * GÖREV FONKSİYONLARI
 * ========================================== */

/* Motor Hız ve Yön Kontrolü */
void Set_Motor_Speed(uint16_t left_pwm, uint16_t right_pwm) {
    // Sınırlandırma
    if (left_pwm > PWM_ARR_VAL) left_pwm = PWM_ARR_VAL;
    if (right_pwm > PWM_ARR_VAL) right_pwm = PWM_ARR_VAL;

    TIM2->CCR2 = left_pwm;
    TIM2->CCR4 = right_pwm;
}

/* Çizgi İzleme Algoritması */
void Line_Follower_Loop(void) {
    // Sensörleri Oku (1: Siyah, 0: Beyaz varsayımı - Sensör tipine göre değişebilir!)
    // IDR registerından ilgili bitleri maskeleyip 1 veya 0'a dönüştürüyoruz.
    uint8_t left  = (GPIOB->IDR & (1 << PIN_SENSOR_L)) ? 1 : 0;
    uint8_t right = (GPIOB->IDR & (1 << PIN_SENSOR_R)) ? 1 : 0;

    /* Senaryolar:
       L=0, R=0 (Beyaz-Beyaz) -> Düz Git
       L=1, R=0 (Siyah-Beyaz) -> Sola Dön (Çizgi solda)
       L=0, R=1 (Beyaz-Siyah) -> Sağa Dön (Çizgi sağda)
       L=1, R=1 (Siyah-Siyah) -> Dur (Veya kavşak)
    */

    if (left == 0 && right == 0) {
        // İkisi de beyaz -> Düz
        Set_Motor_Speed(SPEED_FAST, SPEED_FAST);
    }
    else if (left == 1 && right == 0) {
        // Sol siyah -> Sola dön (Sağ motor hızlı, sol durur/yavaşlar)
        Set_Motor_Speed(SPEED_STOP, SPEED_TURN);
    }
    else if (left == 0 && right == 1) {
        // Sağ siyah -> Sağa dön (Sol motor hızlı, sağ durur/yavaşlar)
        Set_Motor_Speed(SPEED_TURN, SPEED_STOP);
    }
    else {
        // İkisi de siyah -> Dur
        Set_Motor_Speed(SPEED_STOP, SPEED_STOP);
    }
}

/* Buton Okuma ve Debounce */
void Button_Check(void) {
    static uint8_t last_btn_state = 1; // Pull-up olduğu için boşta 1
    uint8_t curr_btn_state = (GPIOB->IDR & (1 << PIN_BUTTON)) ? 1 : 0;

    // Düşen kenar (1 -> 0) algıla
    if (last_btn_state == 1 && curr_btn_state == 0) {
        Simple_Delay_ms(50); // Debounce
        // Buton hala basılı mı?
        if (!(GPIOB->IDR & (1 << PIN_BUTTON))) {
            // Durum Değiştir (Toggle)
            if (currentStat == STATE_IDLE) {
                currentStat = STATE_RUN;
                // Çalışmaya başladığını belli et (Kısa bip)
                GPIOB->ODR |= (1 << PIN_BUZZER);
                Simple_Delay_ms(50);
                GPIOB->ODR &= ~(1 << PIN_BUZZER);
            } else {
                currentStat = STATE_IDLE;
            }
        }
    }
    last_btn_state = curr_btn_state;
}

/* Tek Kanal ADC Okuma (PA0) */
uint16_t ADC_Read(void) {
    ADC1->SQR3 = 0; // Channel 0 Seç
    ADC1->CR2 |= (1 << 22); // SWSTART (Conversion başlat)
    while (!(ADC1->SR & (1 << 1))); // EOC bitini bekle
    return (uint16_t)(ADC1->DR & 0xFFF);
}

/* Batarya Güvenliği */
void Check_Battery_Voltage(void) {
    uint16_t raw_adc = ADC_Read();

    // Integer Matematik ile mV hesabı (Float'tan daha hızlıdır)
    // Formül: (ADC * 3300 * DIV_FACTOR) / 4095
    uint32_t voltage_mv = (raw_adc * ADC_REF_MV * ADC_DIV_FACTOR) / 4095;

    if (voltage_mv < BATTERY_LOW_MV) {
        // Kritik seviye!

        // 1. Motorları Kapat
        Set_Motor_Speed(0, 0);

        // 2. Buzzer'ı sürekli öttür
        GPIOB->ODR |= (1 << PIN_BUZZER);

        // 3. Sonsuz döngüye gir (Reset gerektirir)
        while (1) {
            __NOP();
        }
    }
}

/* Basit gecikme fonksiyonu (Bloklayıcı) */
void Simple_Delay_ms(uint32_t ms) {
    // 8MHz'de kabaca kalibrasyon
    volatile uint32_t i, j;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 800; j++) { // Döngü sayısı deneme/yanılma ile bulunur
            __NOP();
        }
    }
}
